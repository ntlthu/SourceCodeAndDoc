import React from 'react'

export default function CardSanPham(props) {
  return (
    <div>
        Item san pham
    </div>
  )
}
