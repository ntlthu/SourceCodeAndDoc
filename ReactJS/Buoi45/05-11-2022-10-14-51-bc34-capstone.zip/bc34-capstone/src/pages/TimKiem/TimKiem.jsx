import React from 'react'

export default function TimKiem() {
  return (
    <div>TimKiem</div>
  )
}
