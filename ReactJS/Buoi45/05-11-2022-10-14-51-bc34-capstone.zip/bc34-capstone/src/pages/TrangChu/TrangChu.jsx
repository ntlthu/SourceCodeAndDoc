import React from 'react'
import CardSanPham from '../../components/CardSanPham/CardSanPham'

export default function TrangChu() {
  return (
    <div>
      Trang chủ
      <CardSanPham />
    </div>
  )
}
