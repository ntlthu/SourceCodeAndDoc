import React from 'react'

export default function LayoutAdmin() {
  return (
    <div>LayoutAdmin</div>
  )
}
