export const DOMAIN_BE = "https://shop.cyberlearn.vn/api"
export const USER_LOGIN = "user";